package com.tatvamasi.jarvis

import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings

/**
 * Foreground service that listens ON-DEVICE (Vosk, offline Indian-English model) for "Jarvis".
 * No audio is recorded, stored or streamed. On a wake it releases the mic,
 * chimes, and opens My Life on the Jarvis tab.
 */
class WakeService : Service() {

    companion object {
        const val A_START = "start"
        const val A_PAUSE = "pause"
        const val A_RESUME = "resume"
        const val A_RELOAD = "reload"
        const val A_STOP = "stop"

        @Volatile var status: String = "Off"
        @Volatile var running = false

        fun send(c: Context, action: String) {
            val i = Intent(c, WakeService::class.java).setAction(action)
            try {
                if (action == A_START) c.startForegroundService(i) else if (running) c.startService(i)
            } catch (_: Exception) {}
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var pm: SpeechService? = null
    private var model: Model? = null
    private var loading = false
    private var foreground = false
    private var inCall = false
    private var lowBatt = false
    private var keyBad = false
    private var lastError: String? = null
    private var lastWake = 0L
    private var cooldownUntil = 0L
    private var retryAt = 0L
    private var backoff = 2000L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == A_STOP || !Prefs.enabled(this)) {
            if (action == A_STOP) Prefs.setEnabled(this, false)
            shutdown(); return START_NOT_STICKY
        }
        if (!foreground && !goForeground()) { stopSelf(); return START_NOT_STICKY }
        when (action) {
            A_PAUSE -> Prefs.setUserPaused(this, true)
            A_RESUME, A_START -> { Prefs.setUserPaused(this, false); cooldownUntil = 0; resetErrors() }
            A_RELOAD -> { stopEngine(); resetErrors() }
        }
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }

    private fun resetErrors() { keyBad = false; lastError = null; retryAt = 0; backoff = 2000L }

    private fun goForeground(): Boolean = try {
        Notif.channels(this)
        val n = buildStatus()
        if (Build.VERSION.SDK_INT >= 29) startForeground(Notif.N_STATUS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(Notif.N_STATUS, n)
        foreground = true; running = true; true
    } catch (e: Exception) {
        // Android does not allow a microphone service to start from the background
        // (after a reboot, a crash restart, or when the app was not open). Never bypass it.
        Notif.resumeAlert(this, "Jarvis stopped listening", "Android paused background listening. Tap to turn \"Hey Jarvis\" back on.")
        false
    }

    /** Checks calls, battery and pauses every few seconds (cheap; no audio work). */
    private val tick = object : Runnable {
        override fun run() {
            val mode = getSystemService(AudioManager::class.java).mode
            inCall = mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION || mode == AudioManager.MODE_RINGTONE
            val bm = getSystemService(BatteryManager::class.java)
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            lowBatt = Prefs.batterySaver(this@WakeService) && level in 1..14 && !bm.isCharging
            sync()
            h.postDelayed(this, 4000)
        }
    }

    private fun wanted(): Boolean {
        val now = System.currentTimeMillis()
        return !Prefs.userPaused(this) && !inCall && !lowBatt && !keyBad && now >= cooldownUntil && now >= retryAt
    }

    private fun sync() {
        if (wanted() && pm == null) startEngine()
        else if (!wanted() && pm != null) stopEngine()
        updateStatus()
    }

    private fun startEngine() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastError = "Microphone permission is off"; keyBad = true; return
        }
        val m = model
        if (m == null) {
            if (loading) return
            loading = true; lastError = "Preparing the offline speech model (first time only)…"
            StorageService.unpack(applicationContext, "model", "model",
                { loaded -> h.post { model = loaded; loading = false; lastError = null; sync() } },
                { e -> h.post { loading = false; keyBad = true; lastError = "Speech model could not load: " + (e.message ?: "error") } })
            return
        }
        try {
            // Tiny grammar: only "jarvis" phrases or unknown speech, so random talk rarely matches.
            val rec = Recognizer(m, 16000f, "[\"jarvis\", \"hey jarvis\", \"ok jarvis\", \"[unk]\"]")
            rec.setWords(true)
            val sv = SpeechService(rec, 16000f)
            sv.startListening(listener)
            pm = sv; lastError = null; backoff = 2000L
        } catch (e: Exception) {
            pm = null; scheduleRetry("Microphone busy — retrying")
        }
    }

    /** Wake only on a final, confident "jarvis" word. Sensitivity sets the confidence needed. */
    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {}
        override fun onResult(hypothesis: String?) = check(hypothesis)
        override fun onFinalResult(hypothesis: String?) = check(hypothesis)
        override fun onError(e: Exception?) { h.post { stopEngine(); scheduleRetry("Microphone busy — retrying"); updateStatus() } }
        override fun onTimeout() {}
    }

    private fun check(json: String?) {
        if (json == null) return
        try {
            val words = JSONObject(json).optJSONArray("result") ?: return
            val need = 0.95 - Prefs.sens(this) / 100.0 * 0.4   // 55% -> 0.73
            for (i in 0 until words.length()) {
                val w = words.getJSONObject(i)
                if (w.optString("word") == "jarvis" && w.optDouble("conf", 0.0) >= need) { h.post { onWake() }; return }
            }
        } catch (_: Exception) {}
    }

    private fun stopEngine() {
        try { pm?.stop() } catch (_: Exception) {}
        try { pm?.shutdown() } catch (_: Exception) {}
        pm = null
    }

    private fun scheduleRetry(msg: String) {
        lastError = msg
        retryAt = System.currentTimeMillis() + backoff
        backoff = (backoff * 2).coerceAtMost(60_000L)
    }

    private fun onWake() {
        val now = System.currentTimeMillis()
        if (now - lastWake < 6000) return            // ignore double triggers
        lastWake = now
        cooldownUntil = now + Prefs.pauseSecs(this) * 1000L
        stopEngine()                                  // free the mic for My Life
        feedback()
        openMyLife(this)
        updateStatus()
    }

    private fun feedback() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 180)
            h.postDelayed({ tg.release() }, 600)
        } catch (_: Exception) {}
        try {
            getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun statusText(): String {
        val now = System.currentTimeMillis()
        return when {
            keyBad -> lastError ?: "Needs setup"
            loading -> lastError ?: "Preparing…"
            Prefs.userPaused(this) -> "Paused — microphone off"
            inCall -> "Paused during a call"
            lowBatt -> "Paused — battery below 15%"
            now < cooldownUntil -> "My Life opened — wake word back in ${((cooldownUntil - now) / 1000) + 1}s"
            pm != null -> "Listening for \"Jarvis\" — offline, on this phone"
            lastError != null -> lastError!!
            else -> "Starting…"
        }
    }

    private fun pi(action: String, code: Int) = PendingIntent.getService(
        this, code, Intent(this, WakeService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildStatus(): Notification {
        val paused = Prefs.userPaused(this)
        val cooling = System.currentTimeMillis() < cooldownUntil
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_jarvis)
        val b = Notification.Builder(this, Notif.CH_STATUS)
            .setSmallIcon(R.drawable.ic_jarvis)
            .setContentTitle(if (pm != null) "Jarvis is listening" else "Jarvis")
            .setContentText(statusText())
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
        if (paused || cooling) b.addAction(Notification.Action.Builder(icon, "Resume", pi(A_RESUME, 11)).build())
        else b.addAction(Notification.Action.Builder(icon, "Pause (mute mic)", pi(A_PAUSE, 12)).build())
        b.addAction(Notification.Action.Builder(icon, "Turn off", pi(A_STOP, 13)).build())
        return b.build()
    }

    private fun updateStatus() {
        status = statusText()
        if (foreground) try { getSystemService(NotificationManager::class.java).notify(Notif.N_STATUS, buildStatus()) } catch (_: Exception) {}
    }

    private fun shutdown() {
        h.removeCallbacksAndMessages(null)
        stopEngine()
        if (foreground) stopForeground(STOP_FOREGROUND_REMOVE)
        foreground = false; running = false; status = "Off"
        stopSelf()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        stopEngine()
        running = false; status = "Off"
        super.onDestroy()
    }
}

/** Opens My Life (Jarvis tab). Over the lock screen it asks you to unlock first. */
fun openMyLife(c: Context) {
    val i = Intent(c, LaunchActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    val pi = PendingIntent.getActivity(c, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    if (Settings.canDrawOverlays(c)) {
        try { c.startActivity(i); return } catch (_: Exception) {}
    }
    // Without "display over other apps", Android only allows a full-screen / heads-up notification.
    Notif.channels(c)
    val n = Notification.Builder(c, Notif.CH_WAKE)
        .setSmallIcon(R.drawable.ic_jarvis)
        .setContentTitle("Yes, sir?")
        .setContentText("Tap to talk to Jarvis in My Life")
        .setCategory(Notification.CATEGORY_REMINDER)
        .setFullScreenIntent(pi, true)
        .setContentIntent(pi)
        .setAutoCancel(true)
        .setTimeoutAfter(30_000)
        .build()
    try { c.getSystemService(NotificationManager::class.java).notify(Notif.N_WAKE, n) } catch (_: Exception) {}
}
