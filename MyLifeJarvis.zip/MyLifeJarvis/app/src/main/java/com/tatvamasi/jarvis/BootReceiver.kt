package com.tatvamasi.jarvis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Android does not let an app switch the microphone on by itself after a reboot or update.
 * So we only remind you with a notification; one tap turns listening back on.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.enabled(c)) Notif.resumeAlert(
            c, "Turn \"Hey Jarvis\" back on?",
            "Your phone restarted, so Android switched background listening off. Tap to resume."
        )
    }
}
