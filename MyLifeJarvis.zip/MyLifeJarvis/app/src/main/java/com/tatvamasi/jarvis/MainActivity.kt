package com.tatvamasi.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var toggle: Switch
    private lateinit var pauseBtn: Button
    private lateinit var permBox: LinearLayout
    private var quiet = false
    private var pendingStart = false

    private val ink = 0xFFE8F5EE.toInt()
    private val soft = 0xFFB9D3C6.toInt()
    private val mint = 0xFF2FD39A.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notif.channels(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(48))
        }
        val scroll = ScrollView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF0D4A34.toInt(), 0xFF06231A.toInt(), 0xFF020D09.toInt()))
            addView(root)
        }
        setContentView(scroll)

        root.addView(text("Jarvis", 34f, ink, true))
        root.addView(text("Say \"Jarvis\" or \"Hey Jarvis\" — even with My Life closed or the screen locked — and Jarvis opens, ready to talk.", 15f, soft))
        status = text("", 18f, mint, true).apply { setPadding(dp(16), dp(14), dp(16), dp(14)); background = card(0x22FFFFFF) }
        root.addView(status, lp(top = 16))

        toggle = Switch(this).apply {
            text = "Background listening"; textSize = 18f; setTextColor(ink)
            setPadding(0, dp(14), 0, dp(6))
            setOnCheckedChangeListener { _, on -> if (!quiet) { if (on) askConsentThenStart() else turnOff() } }
        }
        root.addView(toggle)
        pauseBtn = button("Pause (mute microphone)") {
            WakeService.send(this, if (Prefs.userPaused(this)) WakeService.A_RESUME else WakeService.A_PAUSE)
            h.postDelayed({ refresh() }, 300)
        }
        root.addView(pauseBtn, lp(top = 6))
        root.addView(button("Test: open Jarvis now") { startActivity(Intent(this, LaunchActivity::class.java)) }, lp(top = 6))

        root.addView(header("1. Wake word"))
        root.addView(text("Works fully offline with a built-in Indian-English speech model. No account or key needed. The first start takes a few seconds to prepare it.", 14f, soft))

        root.addView(header("2. Where Jarvis opens"))
        val url = EditText(this).apply { setText(Prefs.url(this@MainActivity)); setTextColor(ink); textSize = 13f }
        root.addView(url)
        root.addView(button("Save") {
            Prefs.setUrl(this, url.text.toString())
            WakeService.send(this, WakeService.A_RELOAD); toast("Saved")
        }, lp(top = 4))

        root.addView(header("3. Tuning"))
        val sensLabel = text("", 14f, soft)
        root.addView(sensLabel)
        root.addView(seek(30, 80, Prefs.sens(this), { v -> sensLabel.text = "Wake sensitivity: $v% (lower = fewer accidental wake-ups)"; Prefs.setSens(this, v) }) {
            WakeService.send(this, WakeService.A_RELOAD)
        })
        val pauseLabel = text("", 14f, soft)
        root.addView(pauseLabel)
        root.addView(seek(20, 300, Prefs.pauseSecs(this), { v -> pauseLabel.text = "After waking, keep the wake word off for ${v}s so My Life can use the mic"; Prefs.setPauseSecs(this, v) }) {})
        root.addView(CheckBox(this).apply {
            text = "Pause automatically when battery is below 15%"; setTextColor(ink); isChecked = Prefs.batterySaver(this@MainActivity)
            setOnCheckedChangeListener { _, b -> Prefs.setBatterySaver(this@MainActivity, b) }
        })

        root.addView(header("4. Work when locked or minimised"))
        permBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(permBox)

        root.addView(header("Privacy and limits"))
        root.addView(text(
            "• The wake word is detected entirely on this phone, even offline. No audio is recorded, saved or sent anywhere.\n" +
            "• Android shows a green microphone dot and a permanent notification while listening. Use Pause there any time.\n" +
            "• Listening pauses during calls and, if you choose, on low battery. It resumes on its own.\n" +
            "• After waking, the mic is handed to My Life, where you tap the orb and speak. Jarvis's answers, memory and approvals all live in My Life.\n" +
            "• If you Force stop this app, or after the phone restarts, Android switches listening off. Open this app (or tap its notification) to turn it back on.\n" +
            "• Some phones (Xiaomi, Oppo, Vivo, Realme, Samsung) also need Autostart / \"Allow background activity\" in App info.", 14f, soft))
    }

    override fun onResume() { super.onResume(); refresh(); buildPerms(); h.post(loop)
        if (intent?.getBooleanExtra("resume", false) == true) { intent.removeExtra("resume"); if (Prefs.enabled(this)) start() }
    }
    override fun onPause() { super.onPause(); h.removeCallbacks(loop) }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i) }

    private val loop = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }

    private fun refresh() {
        val on = Prefs.enabled(this) && WakeService.running
        status.text = if (on) WakeService.status else if (Prefs.enabled(this)) "Off — tap the switch to resume" else "Background listening is off"
        quiet = true; toggle.isChecked = on; quiet = false
        pauseBtn.isEnabled = on
        pauseBtn.text = if (Prefs.userPaused(this)) "Resume listening" else "Pause (mute microphone)"
    }

    private fun askConsentThenStart() {
        if (Prefs.consent(this)) { start(); return }
        AlertDialog.Builder(this)
            .setTitle("Allow always-on listening?")
            .setMessage("Jarvis will keep the microphone open in the background to hear \"Jarvis\".\n\nIt is checked on this phone only — nothing is recorded or sent. A notification and Android's green mic dot show while it listens, and you can pause or switch it off any time.")
            .setPositiveButton("Allow") { _, _ -> Prefs.setConsent(this, true); start() }
            .setNegativeButton("Not now") { _, _ -> refresh() }
            .setOnCancelListener { refresh() }
            .show()
    }

    private fun start() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) { pendingStart = true; requestPermissions(need.toTypedArray(), 1); return }
        Prefs.setEnabled(this, true); Prefs.setUserPaused(this, false)
        getSystemService(NotificationManager::class.java).cancel(Notif.N_ALERT)
        WakeService.send(this, WakeService.A_START)
        h.postDelayed({ refresh() }, 500)
    }

    private fun turnOff() {
        Prefs.setEnabled(this, false)
        WakeService.send(this, WakeService.A_STOP)
        h.postDelayed({ refresh() }, 300)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (pendingStart) { pendingStart = false; if (micOk) start() else { toast("Jarvis needs the microphone to hear the wake word"); refresh() } }
        buildPerms()
    }

    private fun buildPerms() {
        permBox.removeAllViews()
        val pmgr = getSystemService(PowerManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        fun row(ok: Boolean, label: String, why: String, go: () -> Unit) {
            permBox.addView(button((if (ok) "✓  " else "→  ") + label) { go() }, lp(top = 6))
            permBox.addView(text(why, 13f, soft))
        }
        row(checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && nm.areNotificationsEnabled(),
            "Microphone and notifications", "Needed to hear the wake word and show the listening indicator.") {
            pendingStart = false
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(p.toTypedArray(), 2)
        }
        row(Settings.canDrawOverlays(this), "Open over other apps / lock screen",
            "Lets Jarvis open My Life straight away when you wake it. Without this you get a notification to tap.") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        if (Build.VERSION.SDK_INT >= 34) row(nm.canUseFullScreenIntent(), "Full-screen alerts",
            "Android 14+: lets the wake-up show over the lock screen.") {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        }
        row(pmgr.isIgnoringBatteryOptimizations(packageName), "Battery: unrestricted",
            "Stops Android from putting Jarvis to sleep. The wake-word engine itself uses very little power.") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        row(false, "App info (Autostart on some phones)", "Xiaomi, Oppo, Vivo, Realme: enable Autostart and background activity here.") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    // ---- tiny UI helpers ----
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); setPadding(0, dp(4), 0, dp(4))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun header(s: String) = text(s, 19f, ink, true).apply { setPadding(0, dp(26), 0, dp(4)) }
    private fun card(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0x332FD39A) }
    private fun button(s: String, on: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 15f; setTextColor(ink); gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setPadding(dp(18), dp(12), dp(18), dp(12)); minHeight = dp(52)
        background = card(0x1AFFFFFF); setOnClickListener { on() }
    }
    private fun seek(min: Int, max: Int, value: Int, change: (Int) -> Unit, done: () -> Unit) = SeekBar(this).apply {
        this.max = max - min; progress = value - min; change(value)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) = change(p + min)
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) = done()
        })
    }
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun web(u: String) = try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Exception) {}
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
