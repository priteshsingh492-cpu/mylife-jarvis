package com.tatvamasi.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** Small settings store. Nothing here is sent anywhere. */
object Prefs {
    const val DEFAULT_URL = "https://claude.ai/artifact/NbkhjSbX8zhqJ4cDtGTFFi#jarvis"
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun setKey(c: Context, v: String) = p(c).edit().putString("key", v.trim()).apply()
    fun url(c: Context) = (p(c).getString("url", DEFAULT_URL) ?: DEFAULT_URL).ifBlank { DEFAULT_URL }
    fun setUrl(c: Context, v: String) = p(c).edit().putString("url", v.trim()).apply()

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
    fun consent(c: Context) = p(c).getBoolean("consent", false)
    fun setConsent(c: Context, v: Boolean) = p(c).edit().putBoolean("consent", v).apply()
    fun userPaused(c: Context) = p(c).getBoolean("paused", false)
    fun setUserPaused(c: Context, v: Boolean) = p(c).edit().putBoolean("paused", v).apply()

    /** 30..80 (%). Higher = wakes more easily but more false wakes. */
    fun sens(c: Context) = p(c).getInt("sens", 55)
    fun setSens(c: Context, v: Int) = p(c).edit().putInt("sens", v.coerceIn(30, 80)).apply()
    /** Seconds the wake word stays off after waking, so My Life can use the microphone. */
    fun pauseSecs(c: Context) = p(c).getInt("pauseSecs", 90)
    fun setPauseSecs(c: Context, v: Int) = p(c).edit().putInt("pauseSecs", v.coerceIn(20, 300)).apply()
    fun batterySaver(c: Context) = p(c).getBoolean("batt", true)
    fun setBatterySaver(c: Context, v: Boolean) = p(c).edit().putBoolean("batt", v).apply()
}

object Notif {
    const val CH_STATUS = "status"
    const val CH_WAKE = "wake"
    const val N_STATUS = 7
    const val N_WAKE = 8
    const val N_ALERT = 9

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Listening status", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Shows when Jarvis is listening for the wake word" })
        nm.createNotificationChannel(
            NotificationChannel(CH_WAKE, "Jarvis wake-ups", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Opens My Life when you say Jarvis" })
    }

    /** Used when Android won't let the microphone service restart on its own. */
    fun resumeAlert(c: Context, title: String, text: String) {
        channels(c)
        val pi = PendingIntent.getActivity(
            c, 3,
            Intent(c, MainActivity::class.java).putExtra("resume", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(c, CH_WAKE)
            .setSmallIcon(R.drawable.ic_jarvis)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { c.getSystemService(NotificationManager::class.java).notify(N_ALERT, n) } catch (_: Exception) {}
    }
}
