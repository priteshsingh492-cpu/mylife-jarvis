package com.tatvamasi.jarvis

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager

/** Invisible hop: wakes the screen, asks to unlock if needed, then opens My Life → Jarvis. */
class LaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        getSystemService(NotificationManager::class.java).cancel(Notif.N_WAKE)
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() = open()
                override fun onDismissCancelled() = finish()
                override fun onDismissError() = finish()
            })
        } else open()
    }

    private fun open() {
        val v = Intent(Intent.ACTION_VIEW, Uri.parse(Prefs.url(this))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val chrome = try { packageManager.getPackageInfo("com.android.chrome", 0); true } catch (_: Exception) { false }
        if (chrome) v.setPackage("com.android.chrome")   // Chrome supports My Life's voice features
        try { startActivity(v) } catch (_: Exception) {
            try { startActivity(v.setPackage(null)) } catch (_: Exception) {}
        }
        finish()
    }
}
