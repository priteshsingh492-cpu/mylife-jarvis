plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tatvamasi.jarvis"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.tatvamasi.jarvis"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}
dependencies {
    // Offline on-device speech engine (Apache-2.0). Audio never leaves the phone.
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}

// Downloads the small Indian-English Vosk model into assets at build time (about 36 MB).
val modelDir = file("src/main/assets/model")
val getVoskModel by tasks.registering {
    onlyIf { !modelDir.resolve("uuid").exists() }
    doLast {
        val zip = layout.buildDirectory.file("vosk.zip").get().asFile
        zip.parentFile.mkdirs()
        java.net.URI("https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip").toURL().openStream().use { i -> zip.outputStream().use { o -> i.copyTo(o) } }
        val tmp = layout.buildDirectory.dir("vosk").get().asFile
        tmp.deleteRecursively()
        project.copy { from(zipTree(zip)); into(tmp) }
        val inner = tmp.listFiles()!!.first { it.isDirectory }
        modelDir.deleteRecursively()
        inner.copyRecursively(modelDir)
        modelDir.resolve("uuid").writeText(System.currentTimeMillis().toString())
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(getVoskModel) }
