plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tatvamasi.jarvis"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.tatvamasi.jarvis"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}
dependencies {
    // On-device wake word engine (built-in "Jarvis" keyword). Audio never leaves the phone.
    implementation("ai.picovoice:porcupine-android:3.0.+")
}
