# Jarvis Wake — "Hey Jarvis" for My Life (Android)

Say **"Jarvis"** or **"Hey Jarvis"** while My Life is closed or the phone is locked. Jarvis chimes, you unlock, and My Life opens on the Jarvis tab, ready to talk.

## Get the APK (no Android Studio needed)
1. Sign in at github.com and create a new **private** repository (for example `mylife-jarvis`).
2. Tap **Add file → Upload files**. Upload everything inside this folder, including the hidden `.github` folder, then tap **Commit**.
   - On a phone, you may find it easier to upload the zip from a PC.
3. Open the **Actions** tab. The "Build Jarvis APK" workflow runs automatically and takes about 5 minutes. You can also start it with **Run workflow**.
4. When the run is green, open it and download **MyLife-Jarvis-APK**. Unzip it and install `app-debug.apk`. Allow "Install unknown apps" when Android asks.

## Set up on the phone
1. No account or key is needed: the wake word runs offline with a built-in Indian-English model.
2. Turn on **Background listening**, read the consent message, and allow the microphone and notifications.
3. In step 4, enable the remaining permissions:
   - Open over other apps
   - Full-screen alerts (Android 14+)
   - Battery: unrestricted
   - Autostart, on Xiaomi, Oppo, Vivo or Realme phones
4. Open My Life in **Chrome** once and sign in to Claude. Wake-ups open it there, because Chrome supports My Life's voice features.

## How it works
- A foreground service runs the offline Vosk speech engine, listening only for "Jarvis", **on the phone itself**. No audio is recorded or sent anywhere.
- When it hears the wake word, it:
  - ignores repeat triggers within 6 seconds,
  - releases the microphone, then chimes and vibrates,
  - opens My Life at `#jarvis` (over the lock screen, it asks you to unlock first),
  - stays off for 90 seconds by default, so My Life can use the microphone.
- From there, Jarvis's brain, memory, approvals, reminders and history are the existing ones in My Life. Tap the orb and speak.

## Controls
- **Notification:** shows the current status, with **Pause (mute mic)**, **Resume** and **Turn off** buttons.
- **Automatic pauses:** listening pauses during calls and below 15% battery (you can switch the battery pause off).
- **Settings:**
  - the sensitivity slider (lower means fewer accidental wake-ups)
  - how long the wake word stays off after waking

## Android limits it respects
- After a **reboot or update**, Android doesn't let apps turn the microphone on by themselves. You get a "Tap to resume" notification instead.
- If you **Force stop** the app, listening stays off until you open the app again.
- If Android kills the service in the background, it can't restart the microphone by itself. You get a notification to tap.
- The app can't answer by voice while the phone is locked. You unlock first, then talk in My Life.
